#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include "AnalizadorEstadistico.h"

using namespace std;

int main() {
    AnalizadorEstadistico archivo1("Desktop\\ProjectoPOO\\LectorCSV\\data\\waterQuality.csv");
    AnalizadorEstadistico archivo2("Desktop\\ProjectoPOO\\LectorCSV\\data\\globalAirPollutionDataset.csv"); //checar si se dbee poner path entero

    archivo1.leerArchivo();
    archivo2.leerArchivo();

    archivo1.imprimirDatos();



    return 0;
}